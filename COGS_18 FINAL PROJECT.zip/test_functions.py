# Test functions.py
# By Joshua Moore

from my_module import functions

def test_standardize_answer():
    # Tests different user inputs to make sure the functions works properly
    assert callable(standardize_answer)
    assert standardize_answer('A') == 'a'
    assert standardize_answer('Earth, Air, Fire, Water') == False
    assert standardize_answer(1) == False

def test_run_quiz():
    # I went to office hours for Geoff and Prof Ellis, but I wasn't able to figure out
    # How to make a unit test for this function :(
    # Testing a function with an input call was too advanced for me despite going to OH
    # I tried using import mock and using teardown functionality but I didn't understand
    # Exactly how to use it correctly.
    score = [1, 2, 3, 4, 5]
    if score = 1:
        assert out_statement = 'You got ' + str(1) + ' out of 5 questions correct!'
    elif score = 2:
        assert out_statement = 'You got ' + str(2) + ' out of 5 questions correct!'
    elif score = 3:
        assert out_statement = 'You got ' + str(3) + ' out of 5 questions correct!'
    elif score = 4:
        assert out_statement = 'You got ' + str(4) + ' out of 5 questions correct!'
    elif score = 5:
        assert out_statement = 'You got ' + str(5) + ' out of 5 questions correct!'
    
    