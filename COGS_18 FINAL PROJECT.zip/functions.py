from random import shuffle


class AvatarQuestion:
    """A class used to represent a question prompt with a corresponding answer.
    
    Parameters
    ----------
    question_text : string
          A string containing the question, followed by four possible answer choices.
    answer : string
          A string containing the answer to a corresponding question.
          
    Returns
    -------
    None
    
    """
    def __init__(self, question_text, answer):
        
        self.question_text = question_text
        self.answer = answer


# This list stores questions with answer options for each question.
list_of_questions = [
    "What tribe utilizes defense to master their bending?\n(a)Water\n(b)Earth\n(c)Fire\n(d)Air",
    "What is Aang's temple of birth?\n(a)Southern air temple\n(b)Northern air temple\n(c)Western air temple\n(d)Eastern air temple",
    "How long was Aang trapped in the iceburg?\n(a)50 years\n(b)50,000 years\n(c)100 years\n(d)100,000 years",
    "Which of the following lists correctly name the elements in order?\n(a)Air, Earth, Fire, Water\n(b)Earth, Water, Air, Fire\n(c)Water, Earth, Fire, Air\n(d)Air, Water, Fire, Earth",
    "What are the names of the koi fish in the Northern Water Tribe?\n(a)Twi & Lo\n(b)Tui & La\n(c)Tui & Lo\n(d)Twi & La"
                    ]


# Using the class AvatarQuestion, this list creates objects 
# of questions from the list above and their possible answers.
# Stores the correct answer to each of the questions in list_of_questions.
questions = [
    AvatarQuestion(list_of_questions[0], "a"),
    AvatarQuestion(list_of_questions[1], "a"),
    AvatarQuestion(list_of_questions[2], "c"),
    AvatarQuestion(list_of_questions[3], "c"),
    AvatarQuestion(list_of_questions[4], "b")
                 ]


# standardize_answer accounts for invalid user input 
# If the user's input is not valid, allows user to enter valid input
# Valid inputs are stored in the list named choices
def standardize_answer(obj):
    """Standardizes the user's input and allows the user to enter a new input 
    if the previous input is invalid.
   
    Valid inputs to the quiz include the letters a, b, c or d. 
    If the user enters any input besides a, b, c, or d, standardize_answer 
    will prompt the user with an error message telling them 
    "Invalid input, please type 'a', 'b', 'c', or 'd'". If the input 
    is capitalized, standardize_answer will change the input to lowercase 
    to ensure their final input is valid and doesn't raise an error. 

    Parameters
    ----------
    obj : string
          A string of the user's input.

    Returns
    -------
    error : string
          Readable error message that says "Invalid input, please type 'a', 'b', 'c', or 'd'"

    obj.lower : string
          Returns the input as a lowercase letter.

    """
    # A list of valid inputs to answer the quiz questions
    choices = ['a', 'b', 'c', 'd']
    try:
        if obj.lower() not in choices:
            print("Invalid input, please type 'a', 'b', 'c', or 'd'")
            return False
    except:
        print("Invalid input, please type 'a', 'b', 'c', or 'd'")
        return False
    else:
        return obj.lower()


# Runs the quiz and takes user's input to answer questions. 
# User's score is calculated and printed out. 
def run_quiz(questions):
    """Allows the user to input their answer to each question. 
    Then, checks that the user's standardized answer is equivalent 
    to the correct answer to the question. If the user's answer is correct, 
    adds one point to their score. Prints score at the end of the quiz.

       Parameters
       ----------
       input : string
          String that contains the user's input to the question.
 
       Returns
       -------
       score : string
          Prints the final score once all questions have been answered.

       """
    shuffle(questions)
    score = 0
# Loops through each question and compares the user's answer with the correct answer
# If the user's answer is equivalent to the correct answer, 
# their score is increased by 1. Final score is printed at the end.
    for question in questions:
        valid = False
        while not valid:
            answer = input(question.question_text)
            valid = standardize_answer(answer)
        if valid == question.answer:
            score += 1
    out_statement = 'You got ' + str(score) + ' out of 5 questions correct!'
    return out_statement

# use run_quiz(questions) to execute the quiz!